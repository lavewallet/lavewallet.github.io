import React from 'react'
import Container from '/components/views/BTC/Container'

export default function ContainerLTC() {
    return <Container />
}
