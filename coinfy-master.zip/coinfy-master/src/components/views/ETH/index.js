import React from 'react'
import Container from '/components/views/BTC/Container'
import Export from '/components/views/ETH/Export'

export default function ContainerETH() {
    return <Container Export={Export} />
}
